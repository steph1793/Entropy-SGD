# Entropy SGD
This is a keras implementation of Entropy SGD.
More details on the paper : https://arxiv.org/abs/1611.01838
